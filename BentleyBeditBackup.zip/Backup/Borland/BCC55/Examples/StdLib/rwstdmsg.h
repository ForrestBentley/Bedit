#define _RW_MSG_START 0
#define _RW_MSG_HELLO _RW_MSG_START + 1
#define _RW_MSG_GOODBYE _RW_MSG_START + 2
#define _RW_MSG_TREES  _RW_MSG_START + 3

// Not in catalog
#define _RW_MSG_NOGOOD  6
