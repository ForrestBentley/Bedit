**************************************
c:\javamail\contact.java
**************************************
c:\javamail\email.java
**************************************
c:\javamail\javamail.java
			String MailFrom = "Forrest.Bentley@ge.com";
**************************************
c:\javamail\backup\email.java
**************************************
c:\javamail\backup\javamail.java
			String MailFrom = "Forrest.Bentley@ge.com";
**************************************
c:\javamail\backup\javamailer.java
			String MailFrom = "Forrest.Bentley@ge.com";
**************************************
c:\javamail\backup\test.java
**************************************
c:\javamail\backup\testing.java
**************************************
c:\javamail\genericsource\email.java
**************************************
c:\javamail\genericsource\javamail.java
			String MailFrom = "Forrest.Bentley@ge.com";
**************************************
c:\javamail\old\email.java
**************************************
c:\javamail\old\javamail.java
			String MailFrom = "Forrest.Bentley@ge.com";
